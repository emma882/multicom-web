import React from 'react';
import { Phone, CheckCircle, Wifi, MapPin, MessageCircle } from 'lucide-react';

const MulticomLanding = () => {
  const planes = [
    { nombre: "Plan 30Mb", precio: "24.000", popular: false },
    { nombre: "Plan 50Mb", precio: "26.000", popular: true },
    { nombre: "Plan 100Mb", precio: "29.000", popular: false },
  ];

  const zonas = ["Mercedes", "Mariano I Loza", "Felipe Yofre", "Chavarria"];

  const redWpp = (plan) => `https://wa.me! Estoy interesado en el ${plan}`;

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* HEADER */}
      <nav className="flex justify-between items-center p-5 max-w-7xl mx-auto border-b">
        <div className="text-3xl font-black text-red-600 tracking-tighter">MULTICOM</div>
        <a href="https://wa.me" className="bg-red-600 text-white px-6 py-2 rounded-full font-bold hover:bg-red-700 transition">
          Soporte Online
        </a>
      </nav>

      {/* HERO SECTION */}
      <section className="bg-gradient-to-br from-red-600 to-red-800 text-white py-20 px-5 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold mb-6">
          La mejor conexión a internet con FIBRA ÓPTICA
        </h1>
        <p className="text-xl opacity-90 mb-10 max-w-2xl mx-auto">
          Planes residenciales y empresa. Disfrutá de la velocidad real en casa.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <span className="bg-white/20 backdrop-blur-md px-4 py-2 rounded-lg flex items-center gap-2">
            <CheckCircle size={18} /> Instalación GRATIS
          </span>
          <span className="bg-white/20 backdrop-blur-md px-4 py-2 rounded-lg flex items-center gap-2">
            <Wifi size={18} /> Router WiFi en comodato
          </span>
        </div>
      </section>

      {/* PLANES */}
      <section className="py-20 px-5 max-w-7xl mx-auto" id="planes">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Elegí tu Plan Ideal</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {planes.map((plan) => (
            <div key={plan.nombre} className={`border-2 rounded-3xl p-8 flex flex-col ${plan.popular ? 'border-red-600 shadow-xl scale-105 relative' : 'border-gray-100'}`}>
              {plan.popular && <span className="absolute -top-4 left-1/2 -translate-x-1/2 bg-red-600 text-white px-4 py-1 rounded-full text-sm font-bold">RECOMENDADO</span>}
              <h3 className="text-2xl font-bold mb-4">{plan.nombre}</h3>
              <div className="text-5xl font-black mb-6 text-red-600">${plan.precio}<span className="text-lg text-gray-400 font-normal">/mes</span></div>
              <ul className="mb-10 space-y-3 flex-grow text-gray-600">
                <li className="flex items-center gap-2"><CheckCircle size={18} className="text-green-500"/> Navegación Ilimitada</li>
                <li className="flex items-center gap-2"><CheckCircle size={18} className="text-green-500"/> Fibra Óptica Pura</li>
                <li className="flex items-center gap-2"><CheckCircle size={18} className="text-green-500"/> Soporte Técnico Local</li>
              </ul>
              <a href={redWpp(plan.nombre)} className={`w-full py-4 rounded-xl font-bold text-center transition ${plan.popular ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`}>
                Lo quiero ahora
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* COBERTURA */}
      <section className="bg-gray-50 py-20 px-5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-10">Zonas de Cobertura</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {zonas.map(zona => (
              <div key={zona} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center gap-3">
                <MapPin className="text-red-600" />
                <span className="font-semibold">{zona}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER / CONTACTO */}
      <footer className="py-10 text-center border-t">
        <p className="text-gray-500 mb-4 font-medium">Multicom © 2024 - Conectando tu mundo.</p>
        <div className="flex justify-center gap-6">
          <a href="tel:3773547475" className="text-gray-400 hover:text-red-600 transition"><Phone /></a>
          <a href="https://wa.me" className="text-gray-400 hover:text-green-500 transition"><MessageCircle /></a>
        </div>
      </footer>

      {/* BOTON FLOTANTE WHATSAPP */}
      <a href="https://wa.me" className="fixed bottom-8 right-8 bg-green-500 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform z-50">
        <MessageCircle size={32} />
      </a>
    </div>
  );
};

export default MulticomLanding;
